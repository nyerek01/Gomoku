package Gomoku;

public enum PlayerLevel { Beginner, Pro, Master, Other }